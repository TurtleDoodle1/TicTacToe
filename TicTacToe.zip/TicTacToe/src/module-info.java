/**
 * 
 */
/**
 * 
 */
module TicTacToe {
	requires java.desktop;
}